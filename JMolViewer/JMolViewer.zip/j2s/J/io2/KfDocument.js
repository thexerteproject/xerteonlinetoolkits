Clazz.declarePackage ("J.io2");
c$ = Clazz.declareType (J.io2, "KfDocument");
