Clazz.declarePackage ("J.adapter.readers.cif");
Clazz.load (["J.adapter.smarter.MSInterface"], "J.adapter.readers.cif.MSCifInterface", null, function () {
Clazz.declareInterface (J.adapter.readers.cif, "MSCifInterface", J.adapter.smarter.MSInterface);
});
