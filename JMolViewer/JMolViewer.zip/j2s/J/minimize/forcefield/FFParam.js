Clazz.declarePackage ("J.minimize.forcefield");
c$ = Clazz.decorateAsClass (function () {
this.iVal = null;
this.dVal = null;
this.sVal = null;
Clazz.instantialize (this, arguments);
}, J.minimize.forcefield, "FFParam");
